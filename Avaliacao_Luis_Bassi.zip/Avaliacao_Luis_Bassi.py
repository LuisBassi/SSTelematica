from email import header
from lib2to3.pgen2 import token
import os
import requests
import datetime as dt
import pytz

os.system('cls')

#Name:Luis Felipe Bassi Silva
#Email:luis.felipe7@hotmail.com
#Cell:31 99967-5918

#URL to communicate with API, my user is already created.
url_login = 'https://c7fdrfqx0f.execute-api.us-east-1.amazonaws.com/Production/login'

#Assigns my user data to the "userdata" variable.
userdata = {
    "user": "luis.felipe.ss",
    "pass": "BJsc"
}

#Request an response by command "post".
response = requests.post(url=url_login, json=userdata)

#Here i want to see if the code worked with my user, and eventually get my access token.
if response.status_code == 200:
    #SUCCESS - Return the code number and reason.
    print('Status Code: ',response.status_code)
    print('Motivo: ',response.reason)
    response_data = response.json()
    #Assigns the token string to the "token" variable.
    token = response_data['token']
    print('Token: ',token)

    print()

    #URL to communicate with API, my token is already generated, now i want to get the breath controll data.
    url_breathcontroll = 'https://c7fdrfqx0f.execute-api.us-east-1.amazonaws.com/Production/breathcontroll'

    #Assigns my token number to a header.
    header = {
        'token': token
    }

    #Here i want to get the data by command request.get.
    response = requests.get(url=url_breathcontroll, headers=header)

    #Here i want to see if the code worked with my token, and eventually get my data.
    if response.status_code == 200:
        #SUCESSO - Return the code number and reason.
        print('Status Code: ',response.status_code)
        print('Motivo: ',response.reason)
        response_data2 = response.json()
        #It assigns the data info to the "data" variable, but only the "history" part is what interests me.
        data = response_data2['history']

        print()
        print("1.A Data (local_time) (DD/MM/YYYY HH24:MI) e o Nome do motorista para os 10 menores valores do teste realizados (Se houver mais que 10, exibir os 10 primeiros).","\nDesconsiderar testes sem nome de motorista")
        print()

        #Defines a function to return the value.
        def ordem_value(value):
            return value['value']
    
        #Organizes my data based on the value, ascending order.
        data.sort(key=ordem_value)

        length_question1 = 1

        #Here i want to get rid of the invalid users and just print the first 10 valid users, ascending order.
        for k in data:
            if not k["driver_name"] == "Não Informado" and not k["driver_name"] == "Não Cadastrado" and length_question1<=10:

                #Assigns the string as date.
                formatted_date = dt.datetime.strptime(k["local_time"],'%Y-%m-%d %H:%M:%S')

                #######################
                #I could use the follow lines to set the date as UTC and convert to a specific timezone, for example 'São Paulo'.
                #formatted_date_tz = formatted_date.replace(tzinfo=pytz.UTC)
                #my_timezone = pytz.timezone('America/Sao_Paulo')
                #local_date = formatted_date_tz.astimezone(my_timezone)
                #######################
            
                print("Data/horário->", formatted_date.strftime('%d/%m/%Y %H:%M')," Nome(s)->", k['driver_name']," Valor do teste->", k['value'])
    
                length_question1 = length_question1+1
    
        print()
        print("2.A Data (local_time) (DD/MM/YYYY HH24:MI), o Nome do motorista e Placa dos Veículos dos 10 maiores valores do teste realizados (Se houver mais que 10, exibir os 10 primeiros).","\nDesconsiderar testes sem nome de motorista.")
        print() 

        #Organizes my data based on the value, descending order.
        data.sort(key=ordem_value, reverse=True)

        length_question2 = 1

        #Here i want to get rid of the invalid users and just print the first 10 valid users, descending order.
        for k in data:
            if not k["driver_name"] == "Não Informado" and not k["driver_name"] == "Não Cadastrado" and length_question2<=10:
                    
                #Assigns the string as date.
                formatted_date = dt.datetime.strptime(k["local_time"],'%Y-%m-%d %H:%M:%S')

                #######################
                #I could use the follow lines to set the date as UTC and convert to a specific timezone, for example 'São Paulo'.
                #formatted_date_tz = formatted_date.replace(tzinfo=pytz.UTC)
                #my_timezone = pytz.timezone('America/Sao_Paulo')
                #local_date = formatted_date_tz.astimezone(my_timezone)
                #######################

                print("Data/horário->", formatted_date.strftime('%d/%m/%Y %H:%M')," Nome(s)->", k['driver_name'], " Placa->", k['label']," Valor do teste->", k['value'])
        
                length_question2 = length_question2+1

        print()
        print("3.Quantos testes foram realizado no mês de dezembro de 2021")
        print()

        length_question3 = 0

        #Here i want to count just the right data by defining an exception "2021-12".
        for k in data:
            if "2021-12" in k["local_time"]:
                    
                length_question3 = length_question3+1

        print("Quantidade de testes realizados no mês de dezembro de 2021: ",length_question3)
        print()

    else:
        #FALHA - Return the code number and reason.
        print('Status Code: ',response.status_code)
        print('Motivo: ',response.reason)

else:
    #FALHA - Return the code number and reason.
    print('Status Code: ',response.status_code)
    print('Motivo: ',response.reason)



